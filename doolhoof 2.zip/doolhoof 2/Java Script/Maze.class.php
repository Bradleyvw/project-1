
<?php

    //onder staan de levels 1 t/m 10

public class Doolhof {

private $level;
}

function __construct__($start = 1){
    $this->level = $start;
}

public function getLevel() {
    return $this->level;
}

public function setLevel($newLevel) {
    if($newLevel > 0 && $newLevel < 11) {
        $this->level = $newLevel;
    }
}

public function draw() {

    // speel het spel
    // ronde behaald?
    $this->level++;
    $tekenhetbord();
}

// properties, methods, etc.
}

$doolhof = new Doolhof(7);
echo $doolhof->getLevel();

$doolhof->setLevel(4);


?>
