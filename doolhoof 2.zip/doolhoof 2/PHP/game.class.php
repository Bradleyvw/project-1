<?php
    class Game {
        private $level;

        public function __construct($startlevel = 1) {
            $this->level = $startlevel;
            draw();
        }

        public function draw() {
            // maak het grid op basis van $this->level;

        }
    }

    $spel = new Game();
