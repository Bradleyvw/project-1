class Game {
    constructor(level) {
        this.level = level;
        draw();
    }

    draw() {
        // bouw het grid op basis van this.level
    }

    play() {
        // doet de rest van de machinerie uitvoeren
    }
}

var spelletje = Game(1)