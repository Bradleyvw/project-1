<?php
    // doolhof-connect.php
    // maakt een connectie met de Database "doolhoof 2"

    $servername="localhost";
    $dbname="doolhof";
    $username="root";
    $password="";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname",
    $username,$password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "connectie gelukt <br/>";
}
catch(PDOException $e)
{
    echo $e->getMessage();
}
?>
